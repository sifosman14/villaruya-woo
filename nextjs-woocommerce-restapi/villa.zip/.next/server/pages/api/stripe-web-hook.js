"use strict";
(() => {
var exports = {};
exports.id = 679;
exports.ids = [679];
exports.modules = {

/***/ 1824:
/***/ ((module) => {

module.exports = require("@woocommerce/woocommerce-rest-api");

/***/ }),

/***/ 8174:
/***/ ((module) => {

module.exports = require("stripe");

/***/ }),

/***/ 7294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ stripe_web_hook)
});

;// CONCATENATED MODULE: external "micro"
const external_micro_namespaceObject = require("micro");
;// CONCATENATED MODULE: ./pages/api/stripe-web-hook.js

const Stripe = __webpack_require__(8174);
const WooCommerceRestApi = (__webpack_require__(1824)["default"]);
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2020-08-27"
});
const webhookSecret = process.env.STRIPE_WEBHOOK_ENDPOINT_SECRET;
const config = {
    api: {
        bodyParser: false
    }
};
const api = new WooCommerceRestApi({
    url: "https://backend.villaruya.co.za/",
    consumerKey: process.env.WC_CONSUMER_KEY,
    consumerSecret: process.env.WC_CONSUMER_SECRET,
    version: "wc/v3"
});
/**
 * Update Order.
 *
 * Once payment is successful or failed,
 * Update Order Status to 'Processing' or 'Failed' and set the transaction id.
 *
 * @param {String} newStatus Order Status to be updated.
 * @param {String} orderId Order id
 * @param {String} transactionId Transaction id.
 *
 * @returns {Promise<void>}
 */ const updateOrder = async (newStatus, orderId, transactionId = "")=>{
    let newOrderData = {
        status: newStatus
    };
    if (transactionId) {
        newOrderData.transaction_id = transactionId;
    }
    try {
        const { data  } = await api.put(`orders/${orderId}`, newOrderData);
        console.log("✅ Order updated data", data);
    } catch (ex) {
        console.error("Order creation error", ex);
        throw ex;
    }
};
const handler = async (req, res)=>{
    if (req.method === "POST") {
        const buf = await (0,external_micro_namespaceObject.buffer)(req);
        const sig = req.headers["stripe-signature"];
        let stripeEvent;
        try {
            stripeEvent = stripe.webhooks.constructEvent(buf, sig, webhookSecret);
            console.log("stripeEvent", stripeEvent);
        } catch (err) {
            res.status(400).send(`Webhook Error: ${err.message}`);
            return;
        }
        if ("checkout.session.completed" === stripeEvent.type) {
            const session = stripeEvent.data.object;
            console.log("sessionsession", session);
            console.log("✅ session.metadata.orderId", session.metadata.orderId, session.id);
            // Payment Success.
            try {
                await updateOrder("processing", session.metadata.orderId, session.id);
            } catch (error) {
                await updateOrder("failed", session.metadata.orderId);
                console.error("Update order error", error);
            }
        }
        res.json({
            received: true
        });
    } else {
        res.setHeader("Allow", "POST");
        res.status(405).end("Method Not Allowed");
    }
};
/* harmony default export */ const stripe_web_hook = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7294));
module.exports = __webpack_exports__;

})();