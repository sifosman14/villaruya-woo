"use strict";
(() => {
var exports = {};
exports.id = 248;
exports.ids = [248];
exports.modules = {

/***/ 8174:
/***/ ((module) => {

module.exports = require("stripe");

/***/ }),

/***/ 55:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {


const stripe = __webpack_require__(8174)(process.env.STRIPE_SECRET_KEY);
module.exports = async (req, res)=>{
    const { session_id  } = req.query;
    const session = await stripe.checkout.sessions.retrieve(session_id);
    res.status(200).json(session);
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(55));
module.exports = __webpack_exports__;

})();