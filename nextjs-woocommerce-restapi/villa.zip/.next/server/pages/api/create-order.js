"use strict";
(() => {
var exports = {};
exports.id = 329;
exports.ids = [329];
exports.modules = {

/***/ 1824:
/***/ ((module) => {

module.exports = require("@woocommerce/woocommerce-rest-api");

/***/ }),

/***/ 2081:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "lodash"
const external_lodash_namespaceObject = require("lodash");
;// CONCATENATED MODULE: ./pages/api/create-order.js
const WooCommerceRestApi = (__webpack_require__(1824)["default"]);

const api = new WooCommerceRestApi({
    url: "https://backend.villaruya.co.za/",
    consumerKey: process.env.WC_CONSUMER_KEY,
    consumerSecret: process.env.WC_CONSUMER_SECRET,
    version: "wc/v3"
});
/**
 * Create order endpoint.
 *
 * @see http://woocommerce.github.io/woocommerce-rest-api-docs/?javascript#create-an-order
 *
 * @param {Object} req Request.
 * @param {Object} res Response.
 *
 * @return {Promise<{orderId: string, success: boolean, error: string}>}
 */ async function handler(req, res) {
    const responseData = {
        success: false,
        orderId: "",
        total: "",
        currency: "",
        error: ""
    };
    if ((0,external_lodash_namespaceObject.isEmpty)(req.body)) {
        responseData.error = "Required data not sent";
        return responseData;
    }
    const data = req.body;
    data.status = "pending";
    data.set_paid = false;
    try {
        const { data: data1  } = await api.post("orders", req.body);
        responseData.success = true;
        responseData.orderId = data1.number;
        responseData.total = data1.total;
        responseData.currency = data1.currency;
        responseData.paymentUrl = data1.payment_url;
        res.json(responseData);
    } catch (error) {
        console.log("error", error);
        /**
		 * Request usually fails if the data in req.body is not sent in the format required.
		 *
		 * @see Data shape expected: https://stackoverflow.com/questions/49349396/create-an-order-with-coupon-lines-in-woocomerce-rest-api
		 */ responseData.error = error.message;
        res.status(500).json(responseData);
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2081));
module.exports = __webpack_exports__;

})();