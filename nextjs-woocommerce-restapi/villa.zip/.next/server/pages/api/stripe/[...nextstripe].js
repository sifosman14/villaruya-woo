"use strict";
(() => {
var exports = {};
exports.id = 603;
exports.ids = [603];
exports.modules = {

/***/ 303:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _nextstripe_)
});

;// CONCATENATED MODULE: external "next-stripe"
const external_next_stripe_namespaceObject = require("next-stripe");
var external_next_stripe_default = /*#__PURE__*/__webpack_require__.n(external_next_stripe_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/stripe/[...nextstripe].js

/* harmony default export */ const _nextstripe_ = (external_next_stripe_default()({
    stripe_key: process.env.STRIPE_SECRET_KEY
}));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(303));
module.exports = __webpack_exports__;

})();