"use strict";
(() => {
var exports = {};
exports.id = 222;
exports.ids = [222];
exports.modules = {

/***/ 7843:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Checkout),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/layout/index.js + 14 modules
var layout = __webpack_require__(6970);
// EXTERNAL MODULE: ./src/utils/constants/endpoints.js
var endpoints = __webpack_require__(7163);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./src/components/image/index.js + 1 modules
var components_image = __webpack_require__(1584);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
;// CONCATENATED MODULE: ./src/components/checkout/checkout-cart-item.js



const CheckoutCartItem = ({ item  })=>{
    const productImg = item?.data?.images?.[0] ?? "";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
        className: "woo-next-cart-item",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: "woo-next-cart-element",
                children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(components_image/* default */.Z, {
                        width: "50",
                        height: "50",
                        altText: productImg?.alt ?? "",
                        sourceUrl: !(0,external_lodash_.isEmpty)(productImg?.src) ? productImg?.src : ""
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                className: "woo-next-cart-element",
                children: item?.data?.name ?? ""
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                className: "woo-next-cart-element",
                children: [
                    item?.currency ?? "",
                    item?.line_subtotal ?? ""
                ]
            })
        ]
    }, item?.productId ?? "");
};
/* harmony default export */ const checkout_cart_item = (CheckoutCartItem);

;// CONCATENATED MODULE: ./src/components/checkout/your-order.js



const YourOrder = ({ cart  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
        children: cart ? /*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                className: "checkout-cart table table-hover w-full mb-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            className: "woo-next-cart-head-container text-left",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    className: "woo-next-cart-heading-el",
                                    scope: "col"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    className: "woo-next-cart-heading-el",
                                    scope: "col",
                                    children: "Product"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    className: "woo-next-cart-heading-el",
                                    scope: "col",
                                    children: "Total"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tbody", {
                        children: [
                            cart?.cartItems?.length && cart.cartItems.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx(checkout_cart_item, {
                                    item: item
                                }, item?.productId ?? index)),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                className: "bg-gray-200",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                        className: "woo-next-checkout-total font-normal text-xl",
                                        children: "Total"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                        className: "woo-next-checkout-total font-bold text-xl",
                                        children: [
                                            cart?.cartItems?.[0]?.currency ?? "",
                                            cart?.totalPrice ?? ""
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        }) : ""
    });
};
/* harmony default export */ const your_order = (YourOrder);

;// CONCATENATED MODULE: ./src/components/checkout/error.js

const Error = ({ errors , fieldName  })=>{
    return errors && errors.hasOwnProperty(fieldName) ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "invalid-feedback d-block text-red-500",
        children: errors[fieldName]
    }) : "";
};
/* harmony default export */ const error = (Error);

;// CONCATENATED MODULE: ./src/components/checkout/payment-modes.js


const PaymentModes = ({ input , handleOnChange  })=>{
    const { errors , paymentMethod  } = input || {};
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mt-3",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(error, {
                errors: errors,
                fieldName: "paymentMethod"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "form-check woo-next-payment-input-container mt-2",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    className: "form-check-label",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            onChange: handleOnChange,
                            value: "bacs",
                            className: "form-check-input mr-3",
                            name: "paymentMethod",
                            type: "radio",
                            checked: "bacs" === paymentMethod
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "woo-next-payment-content",
                            children: "Direct Bank Transfer"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "form-check woo-next-payment-input-container mt-2",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    className: "form-check-label",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            onChange: handleOnChange,
                            value: "paypal",
                            className: "form-check-input mr-3",
                            name: "paymentMethod",
                            type: "radio",
                            checked: "paypal" === paymentMethod
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "woo-next-payment-content",
                            children: "Pay with Paypal"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "form-check woo-next-payment-input-container mt-2",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    className: "form-check-label",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            onChange: handleOnChange,
                            value: "cheque",
                            className: "form-check-input mr-3",
                            name: "paymentMethod",
                            type: "radio",
                            checked: "cheque" === paymentMethod
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "woo-next-payment-content",
                            children: "Check Payments"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "form-check woo-next-payment-input-container mt-2",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    className: "form-check-label",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            onChange: handleOnChange,
                            value: "cod",
                            className: "form-check-input mr-3",
                            name: "paymentMethod",
                            type: "radio",
                            checked: "cod" === paymentMethod
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "woo-next-payment-content",
                            children: "Cash on Delivery"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "form-check woo-next-payment-input-container mt-2",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    className: "form-check-label",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            onChange: handleOnChange,
                            value: "jccpaymentgatewayredirect",
                            className: "form-check-input mr-3",
                            name: "paymentMethod",
                            type: "radio",
                            checked: "jccpaymentgatewayredirect" === paymentMethod
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "woo-next-payment-content",
                            children: "JCC"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "form-check woo-next-payment-input-container mt-2",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    className: "form-check-label",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            onChange: handleOnChange,
                            value: "ccavenue",
                            className: "form-check-input mr-3",
                            name: "paymentMethod",
                            type: "radio",
                            checked: "ccavenue" === paymentMethod
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "woo-next-payment-content",
                            children: "CC Avenue"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "form-check woo-next-payment-input-container mt-2",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    className: "form-check-label",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            onChange: handleOnChange,
                            value: "stripe",
                            className: "form-check-input mr-3",
                            name: "paymentMethod",
                            type: "radio",
                            checked: "stripe" === paymentMethod
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "woo-next-payment-content",
                            children: "Stripe"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "woo-next-checkout-payment-instructions mt-2",
                children: "Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode."
            })
        ]
    });
};
/* harmony default export */ const payment_modes = (PaymentModes);

;// CONCATENATED MODULE: external "validator"
const external_validator_namespaceObject = require("validator");
var external_validator_default = /*#__PURE__*/__webpack_require__.n(external_validator_namespaceObject);
;// CONCATENATED MODULE: ./src/validator/is-empty.js
/**
 * Returns true if the value is undefined/null/empty object/empty string.
 *
 * @param value
 * @return {boolean}
 */ const isEmpty = (value)=>value === undefined || value === null || typeof value === "object" && Object.keys(value).length === 0 || typeof value === "string" && value.trim().length === 0;
/* harmony default export */ const is_empty = (isEmpty);

;// CONCATENATED MODULE: ./src/validator/checkout.js


const validateAndSanitizeCheckoutForm = (data, hasStates = true)=>{
    let errors = {};
    let sanitizedData = {};
    /**
	 * Set the firstName value equal to an empty string if user has not entered the firstName, otherwise the Validator.isEmpty() wont work down below.
	 * Note that the isEmpty() here is our custom function defined in is-empty.js and
	 * Validator.isEmpty() down below comes from validator library.
	 * Similarly we do it for for the rest of the fields
	 */ data.firstName = !is_empty(data.firstName) ? data.firstName : "";
    data.lastName = !is_empty(data.lastName) ? data.lastName : "";
    data.company = !is_empty(data.company) ? data.company : "";
    data.country = !is_empty(data.country) ? data.country : "";
    data.address1 = !is_empty(data.address1) ? data.address1 : "";
    data.address2 = !is_empty(data.address2) ? data.address2 : "";
    data.city = !is_empty(data.city) ? data.city : "";
    data.state = !is_empty(data.state) ? data.state : "";
    data.postcode = !is_empty(data.postcode) ? data.postcode : "";
    data.phone = !is_empty(data.phone) ? data.phone : "";
    data.email = !is_empty(data.email) ? data.email : "";
    data.createAccount = !is_empty(data.createAccount) ? data.createAccount : "";
    data.orderNotes = !is_empty(data.orderNotes) ? data.orderNotes : "";
    // data.paymentMethod = ( ! isEmpty( data.paymentMethod ) ) ? data.paymentMethod : '';
    /**
	 * Checks for error if required is true
	 * and adds Error and Sanitized data to the errors and sanitizedData object
	 *
	 * @param {String} fieldName Field name e.g. First name, last name
	 * @param {String} errorContent Error Content to be used in showing error e.g. First Name, Last Name
	 * @param {Integer} min Minimum characters required
	 * @param {Integer} max Maximum characters required
	 * @param {String} type Type e.g. email, phone etc.
	 * @param {boolean} required Required if required is passed as false, it will not validate error and just do sanitization.
	 */ const addErrorAndSanitizedData = (fieldName, errorContent, min, max, type = "", required)=>{
        /**
		 * Please note that this isEmpty() belongs to validator and not our custom function defined above.
		 *
		 * Check for error and if there is no error then sanitize data.
		 */ if (!external_validator_default().isLength(data[fieldName], {
            min,
            max
        })) {
            errors[fieldName] = `${errorContent} must be ${min} to ${max} characters`;
        }
        if ("email" === type && !external_validator_default().isEmail(data[fieldName])) {
            errors[fieldName] = `${errorContent} is not valid`;
        }
        if ("phone" === type && !external_validator_default().isMobilePhone(data[fieldName])) {
            errors[fieldName] = `${errorContent} is not valid`;
        }
        if (required && external_validator_default().isEmpty(data[fieldName])) {
            errors[fieldName] = `${errorContent} is required`;
        }
        // If no errors
        if (!errors[fieldName]) {
            sanitizedData[fieldName] = external_validator_default().trim(data[fieldName]);
            sanitizedData[fieldName] = "email" === type ? external_validator_default().normalizeEmail(sanitizedData[fieldName]) : sanitizedData[fieldName];
            sanitizedData[fieldName] = external_validator_default().escape(sanitizedData[fieldName]);
        }
    };
    addErrorAndSanitizedData("firstName", "First name", 2, 35, "string", true);
    addErrorAndSanitizedData("lastName", "Last name", 2, 35, "string", true);
    addErrorAndSanitizedData("company", "Company Name", 0, 35, "string", false);
    addErrorAndSanitizedData("country", "Country name", 2, 55, "string", true);
    addErrorAndSanitizedData("address1", "Street address line 1", 12, 100, "string", true);
    addErrorAndSanitizedData("address2", "", 0, 254, "string", false);
    addErrorAndSanitizedData("city", "City field", 3, 25, "string", true);
    addErrorAndSanitizedData("state", "State/County", 0, 254, "string", hasStates);
    addErrorAndSanitizedData("postcode", "Post code", 2, 10, "postcode", true);
    addErrorAndSanitizedData("phone", "Phone number", 10, 15, "phone", true);
    addErrorAndSanitizedData("email", "Email", 11, 254, "email", true);
    // The data.createAccount is a boolean value.
    sanitizedData.createAccount = data.createAccount;
    addErrorAndSanitizedData("orderNotes", "", 0, 254, "string", false);
    // @TODO Payment mode error to be handled later.
    // addErrorAndSanitizedData( 'paymentMethod', 'Payment mode field', 2, 50, 'string', false );
    return {
        sanitizedData,
        errors,
        isValid: is_empty(errors)
    };
};
/* harmony default export */ const checkout = (validateAndSanitizeCheckoutForm);

// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
;// CONCATENATED MODULE: ./src/components/checkout/form-elements/abbr.js


const Abbr = ({ required  })=>{
    if (!required) {
        return null;
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("abbr", {
        className: "text-red-500",
        style: {
            textDecoration: "none"
        },
        title: "required",
        children: "*"
    });
};
Abbr.propTypes = {
    required: (external_prop_types_default()).bool
};
Abbr.defaultProps = {
    required: false
};
/* harmony default export */ const abbr = (Abbr);

// EXTERNAL MODULE: ./src/components/icons/ArrowDown.js
var ArrowDown = __webpack_require__(3447);
;// CONCATENATED MODULE: ./src/components/checkout/country-selection.js





const CountrySelection = ({ input , handleOnChange , countries , isShipping  })=>{
    const { country , errors  } = input || {};
    const inputId = `country-${isShipping ? "shipping" : "billing"}`;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mb-3",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                className: "leading-7 text-sm text-gray-700",
                htmlFor: inputId,
                children: [
                    "Country",
                    /*#__PURE__*/ jsx_runtime_.jsx(abbr, {
                        required: true
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative w-full border-none",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                        onChange: handleOnChange,
                        value: country,
                        name: "country",
                        className: "bg-gray-100 bg-opacity-50 border border-gray-500 text-gray-500 appearance-none inline-block py-3 pl-3 pr-8 rounded leading-tight w-full",
                        id: inputId,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: "",
                                children: "Select a country..."
                            }),
                            !(0,external_lodash_.isEmpty)(countries) && (0,external_lodash_.map)(countries, (country)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    "data-countrycode": country?.countryCode,
                                    value: country?.countryCode,
                                    children: country?.countryName
                                }, country?.countryCode))
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "absolute right-0 mr-1 text-gray-500",
                        style: {
                            top: "25%"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowDown/* default */.Z, {
                            width: 24,
                            height: 24,
                            className: "fill-current"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error, {
                errors: errors,
                fieldName: "country"
            })
        ]
    });
};
/* harmony default export */ const country_selection = (CountrySelection);

;// CONCATENATED MODULE: ./src/components/checkout/states-selection.js






const StateSelection = ({ handleOnChange , input , states , isFetchingStates , isShipping  })=>{
    const { state , errors  } = input || {};
    const inputId = `state-${isShipping ? "shipping" : "billing"}`;
    if (isFetchingStates) {
        // Show loading component.
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "mb-3",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                    className: "leading-7 text-sm text-gray-700",
                    children: [
                        "State/County",
                        /*#__PURE__*/ jsx_runtime_.jsx(abbr, {
                            required: true
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "relative w-full border-none",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("select", {
                        disabled: true,
                        value: "",
                        name: "state",
                        className: "opacity-50 bg-gray-100 bg-opacity-50 border border-gray-500 text-gray-500 appearance-none inline-block py-3 pl-3 pr-8 rounded leading-tight w-full",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("option", {
                            value: "",
                            children: "Loading..."
                        })
                    })
                })
            ]
        });
    }
    if (!states.length) {
        return null;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mb-3",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                className: "leading-7 text-sm text-gray-600",
                htmlFor: inputId,
                children: [
                    "State/County",
                    /*#__PURE__*/ jsx_runtime_.jsx(abbr, {
                        required: true
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative w-full border-none",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                    disabled: isFetchingStates,
                    onChange: handleOnChange,
                    value: state,
                    name: "state",
                    className: external_classnames_default()("bg-gray-100 bg-opacity-50 border border-gray-400 text-gray-500 appearance-none inline-block py-3 pl-3 pr-8 rounded leading-tight w-full", {
                        "opacity-50": isFetchingStates
                    }),
                    id: inputId,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                            value: "",
                            children: "Select a state..."
                        }),
                        states.map((state, index)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: state?.stateName ?? "",
                                children: state?.stateName
                            }, state?.stateCode ?? index))
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error, {
                errors: errors,
                fieldName: "state"
            })
        ]
    });
};
StateSelection.propTypes = {
    handleOnChange: (external_prop_types_default()).func,
    input: (external_prop_types_default()).object,
    states: (external_prop_types_default()).array,
    isFetchingStates: (external_prop_types_default()).bool,
    isShipping: (external_prop_types_default()).bool
};
StateSelection.defaultProps = {
    handleOnChange: ()=>null,
    input: {},
    states: [],
    isFetchingStates: false,
    isShipping: true
};
/* harmony default export */ const states_selection = (/*#__PURE__*/(0,external_react_.memo)(StateSelection));

;// CONCATENATED MODULE: ./src/components/checkout/form-elements/input-field.js




const InputField = ({ handleOnChange , inputValue , name , type , label , errors , placeholder , required , containerClassNames , isShipping  })=>{
    const inputId = `${name}-${isShipping ? "shipping" : ""}`;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: containerClassNames,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                className: "leading-7 text-sm text-gray-700",
                htmlFor: inputId,
                children: [
                    label || "",
                    /*#__PURE__*/ jsx_runtime_.jsx(abbr, {
                        required: required
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                onChange: handleOnChange,
                value: inputValue,
                placeholder: placeholder,
                type: type,
                name: name,
                className: "w-full bg-gray-100 bg-opacity-50 rounded border border-gray-500 focus:border-indigo-500 focus:bg-transparent focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-800 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out",
                id: inputId
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(error, {
                errors: errors,
                fieldName: name
            })
        ]
    });
};
InputField.propTypes = {
    handleOnChange: (external_prop_types_default()).func,
    inputValue: (external_prop_types_default()).string,
    name: (external_prop_types_default()).string,
    type: (external_prop_types_default()).string,
    label: (external_prop_types_default()).string,
    placeholder: (external_prop_types_default()).string,
    errors: (external_prop_types_default()).object,
    required: (external_prop_types_default()).bool,
    containerClassNames: (external_prop_types_default()).string
};
InputField.defaultProps = {
    handleOnChange: ()=>null,
    inputValue: "",
    name: "",
    type: "text",
    label: "",
    placeholder: "",
    errors: {},
    required: false,
    containerClassNames: ""
};
/* harmony default export */ const input_field = (InputField);

;// CONCATENATED MODULE: ./src/components/checkout/user-address.js





const Address = ({ input , countries , states , handleOnChange , isFetchingStates , isShipping  })=>{
    const { errors  } = input || {};
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-wrap overflow-hidden sm:-mx-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(input_field, {
                        name: "firstName",
                        inputValue: input?.firstName,
                        required: true,
                        handleOnChange: handleOnChange,
                        label: "First name",
                        errors: errors,
                        isShipping: isShipping,
                        containerClassNames: "w-full overflow-hidden sm:my-2 sm:px-2 md:w-1/2"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(input_field, {
                        name: "lastName",
                        inputValue: input?.lastName,
                        required: true,
                        handleOnChange: handleOnChange,
                        label: "Last name",
                        errors: errors,
                        isShipping: isShipping,
                        containerClassNames: "w-full overflow-hidden sm:my-2 sm:px-2 md:w-1/2"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(input_field, {
                name: "company",
                inputValue: input?.company,
                handleOnChange: handleOnChange,
                label: "Company Name (Optional)",
                errors: errors,
                isShipping: isShipping,
                containerClassNames: "mb-4"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(country_selection, {
                input: input,
                handleOnChange: handleOnChange,
                countries: countries,
                isShipping: isShipping
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(input_field, {
                name: "address1",
                inputValue: input?.address1,
                required: true,
                handleOnChange: handleOnChange,
                label: "Street address",
                placeholder: "House number and street name",
                errors: errors,
                isShipping: isShipping,
                containerClassNames: "mb-4"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(input_field, {
                name: "address2",
                inputValue: input?.address2,
                handleOnChange: handleOnChange,
                label: "Street address line two",
                placeholder: "Apartment floor unit building floor etc(optional)",
                errors: errors,
                isShipping: isShipping,
                containerClassNames: "mb-4"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(input_field, {
                name: "city",
                required: true,
                inputValue: input?.city,
                handleOnChange: handleOnChange,
                label: "Town/City",
                errors: errors,
                isShipping: isShipping,
                containerClassNames: "mb-4"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(states_selection, {
                input: input,
                handleOnChange: handleOnChange,
                states: states,
                isShipping: isShipping,
                isFetchingStates: isFetchingStates
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-wrap overflow-hidden sm:-mx-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(input_field, {
                        name: "postcode",
                        inputValue: input?.postcode,
                        required: true,
                        handleOnChange: handleOnChange,
                        label: "Post code",
                        errors: errors,
                        isShipping: isShipping,
                        containerClassNames: "w-full overflow-hidden sm:my-2 sm:px-2 md:w-1/2"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(input_field, {
                        name: "phone",
                        inputValue: input?.phone,
                        required: true,
                        handleOnChange: handleOnChange,
                        label: "Phone",
                        errors: errors,
                        isShipping: isShipping,
                        containerClassNames: "w-full overflow-hidden sm:my-2 sm:px-2 md:w-1/2"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(input_field, {
                name: "email",
                type: "email",
                inputValue: input?.email,
                required: true,
                handleOnChange: handleOnChange,
                label: "Email",
                errors: errors,
                isShipping: isShipping,
                containerClassNames: "mb-4"
            })
        ]
    });
};
Address.propTypes = {
    input: (external_prop_types_default()).object,
    countries: (external_prop_types_default()).array,
    handleOnChange: (external_prop_types_default()).func,
    isFetchingStates: (external_prop_types_default()).bool,
    isShipping: (external_prop_types_default()).bool
};
Address.defaultProps = {
    input: {},
    countries: [],
    handleOnChange: ()=>null,
    isFetchingStates: false,
    isShipping: false
};
/* harmony default export */ const user_address = (Address);

// EXTERNAL MODULE: ./src/components/context/index.js
var context = __webpack_require__(6086);
;// CONCATENATED MODULE: ./src/components/checkout/form-elements/checkbox-field.js


const CheckboxField = ({ handleOnChange , checked , name , label , placeholder , containerClassNames  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: containerClassNames,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
            className: "leading-7 text-md text-gray-700 flex items-center cursor-pointer",
            htmlFor: name,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    onChange: handleOnChange,
                    placeholder: placeholder,
                    type: "checkbox",
                    checked: checked,
                    name: name,
                    id: name
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "ml-2",
                    children: label || ""
                })
            ]
        })
    });
};
CheckboxField.propTypes = {
    handleOnChange: (external_prop_types_default()).func,
    checked: (external_prop_types_default()).bool,
    name: (external_prop_types_default()).string,
    type: (external_prop_types_default()).string,
    label: (external_prop_types_default()).string,
    placeholder: (external_prop_types_default()).string,
    containerClassNames: (external_prop_types_default()).string
};
CheckboxField.defaultProps = {
    handleOnChange: ()=>null,
    checked: false,
    name: "",
    label: "",
    placeholder: "",
    errors: {},
    containerClassNames: ""
};
/* harmony default export */ const checkbox_field = (CheckboxField);

;// CONCATENATED MODULE: external "next-stripe/client"
const client_namespaceObject = require("next-stripe/client");
;// CONCATENATED MODULE: external "@stripe/stripe-js"
const stripe_js_namespaceObject = require("@stripe/stripe-js");
;// CONCATENATED MODULE: ./src/utils/checkout/order.js
/**
 * Get line items for create order
 *
 * @param {array} products Products.
 *
 * @returns {*[]|*} Line items, Array of objects.
 */ 
const getCreateOrderLineItems = (products)=>{
    if ((0,external_lodash_.isEmpty)(products) || !(0,external_lodash_.isArray)(products)) {
        return [];
    }
    return products?.map(({ product_id , quantity  })=>{
        return {
            quantity,
            product_id
        };
    });
};
/**
 * Get Formatted create order data.
 *
 * @param order
 * @param products
 * @return {{shipping: {country: *, city: *, phone: *, address_1: (string|*), address_2: (string|*), postcode: (string|*), last_name: (string|*), company: *, state: *, first_name: (string|*), email: *}, payment_method_title: string, line_items: (*[]|*), payment_method: string, billing: {country: *, city: *, phone: *, address_1: (string|*), address_2: (string|*), postcode: (string|*), last_name: (string|*), company: *, state: *, first_name: (string|*), email: *}}}
 */ const getCreateOrderData = (order, products)=>{
    // Set the billing Data to shipping, if applicable.
    const billingData = order.billingDifferentThanShipping ? order.billing : order.shipping;
    // Checkout data.
    return {
        shipping: {
            first_name: order?.shipping?.firstName,
            last_name: order?.shipping?.lastName,
            address_1: order?.shipping?.address1,
            address_2: order?.shipping?.address2,
            city: order?.shipping?.city,
            country: order?.shipping?.country,
            state: order?.shipping?.state,
            postcode: order?.shipping?.postcode,
            email: order?.shipping?.email,
            phone: order?.shipping?.phone,
            company: order?.shipping?.company
        },
        billing: {
            first_name: billingData?.firstName,
            last_name: billingData?.lastName,
            address_1: billingData?.address1,
            address_2: billingData?.address2,
            city: billingData?.city,
            country: billingData?.country,
            state: billingData?.state,
            postcode: billingData?.postcode,
            email: billingData?.email,
            phone: billingData?.phone,
            company: billingData?.company
        },
        payment_method: order?.paymentMethod,
        payment_method_title: order?.paymentMethod,
        line_items: getCreateOrderLineItems(products)
    };
};
/**
 * Create order.
 *
 * @param {Object} orderData Order data.
 * @param {function} setOrderFailedError sets the react state to true if the order creation fails.
 * @param {string} previousRequestError Previous request error.
 *
 * @returns {Promise<{orderId: null, error: string}>}
 */ const createTheOrder = async (orderData, setOrderFailedError, previousRequestError)=>{
    let response = {
        orderId: null,
        total: "",
        currency: "",
        error: ""
    };
    // Don't proceed if previous request has error.
    if (previousRequestError) {
        response.error = previousRequestError;
        return response;
    }
    setOrderFailedError("");
    try {
        const request = await fetch("/api/create-order", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(orderData)
        });
        const result = await request.json();
        if (result.error) {
            response.error = result.error;
            setOrderFailedError("Something went wrong. Order creation failed. Please try again");
        }
        response.orderId = result?.orderId ?? "";
        response.total = result.total ?? "";
        response.currency = result.currency ?? "";
        response.paymentUrl = result.paymentUrl ?? "";
    } catch (error) {
        // @TODO to be handled later.
        console.warn("Handle create order error", error?.message);
    }
    return response;
};

// EXTERNAL MODULE: ./src/utils/cart/index.js + 2 modules
var cart = __webpack_require__(9366);
;// CONCATENATED MODULE: ./src/utils/checkout/index.js

 // @see https://github.com/ynnoj/next-stripe





/**
 * Handle Other Payment Method checkout.
 *
 * @param input
 * @param products
 * @param setRequestError
 * @param setCart
 * @param setIsOrderProcessing
 * @param setCreatedOrderData
 * @return {Promise<{orderId: null, error: string}|null>}
 */ const handleOtherPaymentMethodCheckout = async (input, products, setRequestError, setCart, setIsOrderProcessing, setCreatedOrderData)=>{
    setIsOrderProcessing(true);
    const orderData = getCreateOrderData(input, products);
    const customerOrderData = await createTheOrder(orderData, setRequestError, "");
    const cartCleared = await (0,cart/* clearCart */.LL)(setCart, ()=>{});
    setIsOrderProcessing(false);
    if ((0,external_lodash_.isEmpty)(customerOrderData?.orderId) || cartCleared?.error) {
        setRequestError("Clear cart failed");
        return null;
    }
    setCreatedOrderData(customerOrderData);
    return customerOrderData;
};
/**
 * Handle Stripe checkout.
 *
 * 1. Create Formatted Order data.
 * 2. Create Order using Next.js create-order endpoint.
 * 3. Clear the cart session.
 * 4. On success set show stripe form to true
 *
 * @param input
 * @param products
 * @param setRequestError
 * @param setCart
 * @param setIsProcessing
 *
 * @param setCreatedOrderData
 */ const handleStripeCheckout = async (input, products, setRequestError, setCart, setIsProcessing, setCreatedOrderData)=>{
    setIsProcessing(true);
    const orderData = getCreateOrderData(input, products);
    const customerOrderData = await createTheOrder(orderData, setRequestError, "");
    const cartCleared = await (0,cart/* clearCart */.LL)(setCart, ()=>{});
    setIsProcessing(false);
    if ((0,external_lodash_.isEmpty)(customerOrderData?.orderId) || cartCleared?.error) {
        setRequestError("Clear cart failed");
        return null;
    }
    // On success show stripe form.
    setCreatedOrderData(customerOrderData);
    await createCheckoutSessionAndRedirect(products, input, customerOrderData?.orderId);
    return customerOrderData;
};
/**
 * Create Checkout Session and redirect.
 * @param products
 * @param input
 * @param orderId
 * @return {Promise<void>}
 */ const createCheckoutSessionAndRedirect = async (products, input, orderId)=>{
    const sessionData = {
        success_url: window.location.origin + `/thank-you?session_id={CHECKOUT_SESSION_ID}&order_id=${orderId}`,
        cancel_url: window.location.href,
        customer_email: input.billingDifferentThanShipping ? input?.billing?.email : input?.shipping?.email,
        line_items: getStripeLineItems(products),
        metadata: getMetaData(input, orderId),
        payment_method_types: [
            "card"
        ],
        mode: "payment"
    };
    console.log("sessionData", sessionData);
    let session = {};
    try {
        session = await (0,client_namespaceObject.createCheckoutSession)(sessionData);
    } catch (err) {
        console.log("createCheckout session error", err);
    }
    try {
        const stripe = await (0,stripe_js_namespaceObject.loadStripe)("pk_test_51MM7qhGdEdCnR6s2hQWR8ZVqavNprK1U39di2I5gU7jPD9i5NPsnZMI1TwbJ6GmL6sBRoMN4iP0SKLDZEdJALUjX00n3KYNYod");
        if (stripe) {
            stripe.redirectToCheckout({
                sessionId: session.id
            });
        }
    } catch (error) {
        console.log(error);
    }
};
/**
 * Get Stripe Line Items
 *
 * @param products
 * @return {*[]|*}
 */ const getStripeLineItems = (products)=>{
    if ((0,external_lodash_.isEmpty)(products) && !(0,external_lodash_.isArray)(products)) {
        return [];
    }
    return products.map((product)=>{
        return {
            quantity: product?.quantity ?? 0,
            name: product?.data?.name ?? "",
            images: [
                product?.data?.images?.[0]?.src ?? "" ?? ""
            ],
            amount: Math.round((product?.line_subtotal ?? 0) * 100),
            currency: "usd"
        };
    });
};
/**
 * Get meta data.
 *
 * @param input
 * @param {String} orderId Order Id.
 *
 * @returns {{shipping: string, orderId: String, billing: string}}
 */ const getMetaData = (input, orderId)=>{
    return {
        billing: JSON.stringify(input?.billing),
        shipping: JSON.stringify(input.billingDifferentThanShipping ? input?.billing?.email : input?.shipping?.email),
        orderId
    };
// @TODO
// if ( customerId ) {
//     metadata.customerId = customerId;
// }
};
/**
 * Handle Billing Different Than Shipping.
 *
 * @param input
 * @param setInput
 * @param target
 */ const handleBillingDifferentThanShipping = (input, setInput, target)=>{
    const newState = {
        ...input,
        [target.name]: !input.billingDifferentThanShipping
    };
    setInput(newState);
};
/**
 * Handle Create Account.
 *
 * @param input
 * @param setInput
 * @param target
 */ const handleCreateAccount = (input, setInput, target)=>{
    const newState = {
        ...input,
        [target.name]: !input.createAccount
    };
    setInput(newState);
};
/**
 * Set states for the country.
 *
 * @param {Object} target Target.
 * @param {Function} setTheStates React useState function to set the value of the states basis country selection.
 * @param {Function} setIsFetchingStates React useState function, to manage loading state when request is in process.
 *
 * @return {Promise<void>}
 */ const setStatesForCountry = async (target, setTheStates, setIsFetchingStates)=>{
    if ("country" === target.name) {
        setIsFetchingStates(true);
        const countryCode = target[target.selectedIndex].getAttribute("data-countrycode");
        const states = await getStates(countryCode);
        setTheStates(states || []);
        setIsFetchingStates(false);
    }
};
/**
 * Get states
 *
 * @param {String} countryCode Country code
 *
 * @returns {Promise<*[]>}
 */ const getStates = async (countryCode = "")=>{
    if (!countryCode) {
        return [];
    }
    const { data  } = await external_axios_default().get(endpoints/* WOOCOMMERCE_STATES_ENDPOINT */.yd, {
        params: {
            countryCode
        }
    });
    return data?.states ?? [];
};

;// CONCATENATED MODULE: ./src/components/checkout/checkout-form.js










// Use this for testing purposes, so you dont have to fill the checkout form over an over again.
// const defaultCustomerInfo = {
// 	firstName: 'Imran',
// 	lastName: 'Sayed',
// 	address1: '123 Abc farm',
// 	address2: 'Hill Road',
// 	city: 'Mumbai',
// 	country: 'IN',
// 	state: 'Maharastra',
// 	postcode: '221029',
// 	email: 'codeytek.academy@gmail.com',
// 	phone: '9883778278',
// 	company: 'The Company',
// 	errors: null,
// };
const defaultCustomerInfo = {
    firstName: "",
    lastName: "",
    address1: "",
    address2: "",
    city: "",
    country: "",
    state: "",
    postcode: "",
    email: "",
    phone: "",
    company: "",
    errors: null
};
const CheckoutForm = ({ countriesData  })=>{
    const { billingCountries , shippingCountries  } = countriesData || {};
    const initialState = {
        billing: {
            ...defaultCustomerInfo
        },
        shipping: {
            ...defaultCustomerInfo
        },
        createAccount: false,
        orderNotes: "",
        billingDifferentThanShipping: false,
        paymentMethod: "cod"
    };
    const { 0: cart , 1: setCart  } = (0,external_react_.useContext)(context/* AppContext */.I);
    const { 0: input , 1: setInput  } = (0,external_react_.useState)(initialState);
    const { 0: requestError , 1: setRequestError  } = (0,external_react_.useState)(null);
    const { 0: theShippingStates , 1: setTheShippingStates  } = (0,external_react_.useState)([]);
    const { 0: isFetchingShippingStates , 1: setIsFetchingShippingStates  } = (0,external_react_.useState)(false);
    const { 0: theBillingStates , 1: setTheBillingStates  } = (0,external_react_.useState)([]);
    const { 0: isFetchingBillingStates , 1: setIsFetchingBillingStates  } = (0,external_react_.useState)(false);
    const { 0: isOrderProcessing , 1: setIsOrderProcessing  } = (0,external_react_.useState)(false);
    const { 0: createdOrderData , 1: setCreatedOrderData  } = (0,external_react_.useState)({});
    /**
	 * Handle form submit.
	 *
	 * @param {Object} event Event Object.
	 *
	 * @return Null.
	 */ const handleFormSubmit = async (event)=>{
        event.preventDefault();
        /**
		 * Validate Billing and Shipping Details
		 *
		 * Note:
		 * 1. If billing is different than shipping address, only then validate billing.
		 * 2. We are passing theBillingStates?.length and theShippingStates?.length, so that
		 * the respective states should only be mandatory, if a country has states.
		 */ const billingValidationResult = input?.billingDifferentThanShipping ? checkout(input?.billing, theBillingStates?.length) : {
            errors: null,
            isValid: true
        };
        const shippingValidationResult = checkout(input?.shipping, theShippingStates?.length);
        setInput({
            ...input,
            billing: {
                ...input.billing,
                errors: billingValidationResult.errors
            },
            shipping: {
                ...input.shipping,
                errors: shippingValidationResult.errors
            }
        });
        // If there are any errors, return.
        if (!shippingValidationResult.isValid || !billingValidationResult.isValid) {
            return null;
        }
        // For stripe payment mode, handle the strip payment and thank you.
        if ("stripe" === input.paymentMethod) {
            const createdOrderData = await handleStripeCheckout(input, cart?.cartItems, setRequestError, setCart, setIsOrderProcessing, setCreatedOrderData);
            return null;
        }
        // For Any other payment mode, create the order and redirect the user to payment url.
        const createdOrderData1 = await handleOtherPaymentMethodCheckout(input, cart?.cartItems, setRequestError, setCart, setIsOrderProcessing, setCreatedOrderData);
        if (createdOrderData1.paymentUrl) {
            window.location.href = createdOrderData1.paymentUrl;
        }
        setRequestError(null);
    };
    /*
	 * Handle onchange input.
	 *
	 * @param {Object} event Event Object.
	 * @param {bool} isShipping If this is false it means it is billing.
	 * @param {bool} isBillingOrShipping If this is false means its standard input and not billing or shipping.
	 *
	 * @return {void}
	 */ const handleOnChange = async (event, isShipping = false, isBillingOrShipping = false)=>{
        const { target  } = event || {};
        if ("createAccount" === target.name) {
            handleCreateAccount(input, setInput, target);
        } else if ("billingDifferentThanShipping" === target.name) {
            handleBillingDifferentThanShipping(input, setInput, target);
        } else if (isBillingOrShipping) {
            if (isShipping) {
                await handleShippingChange(target);
            } else {
                await handleBillingChange(target);
            }
        } else {
            const newState = {
                ...input,
                [target.name]: target.value
            };
            setInput(newState);
        }
    };
    const handleShippingChange = async (target)=>{
        const newState = {
            ...input,
            shipping: {
                ...input?.shipping,
                [target.name]: target.value
            }
        };
        setInput(newState);
        await setStatesForCountry(target, setTheShippingStates, setIsFetchingShippingStates);
    };
    const handleBillingChange = async (target)=>{
        const newState = {
            ...input,
            billing: {
                ...input?.billing,
                [target.name]: target.value
            }
        };
        setInput(newState);
        await setStatesForCountry(target, setTheBillingStates, setIsFetchingBillingStates);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: cart ? /*#__PURE__*/ jsx_runtime_.jsx("form", {
            onSubmit: handleFormSubmit,
            className: "woo-next-checkout-form",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-1 md:grid-cols-2 gap-20",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "billing-details",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-xl font-medium mb-4",
                                        children: "Shipping Details"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(user_address, {
                                        states: theShippingStates,
                                        countries: shippingCountries,
                                        input: input?.shipping,
                                        handleOnChange: (event)=>handleOnChange(event, true, true),
                                        isFetchingStates: isFetchingShippingStates,
                                        isShipping: true,
                                        isBillingOrShipping: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(checkbox_field, {
                                    name: "billingDifferentThanShipping",
                                    type: "checkbox",
                                    checked: input?.billingDifferentThanShipping,
                                    handleOnChange: handleOnChange,
                                    label: "Billing different than shipping",
                                    containerClassNames: "mb-4 pt-4"
                                })
                            }),
                            input?.billingDifferentThanShipping ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "billing-details",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-xl font-medium mb-4",
                                        children: "Billing Details"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(user_address, {
                                        states: theBillingStates,
                                        countries: billingCountries.length ? billingCountries : shippingCountries,
                                        input: input?.billing,
                                        handleOnChange: (event)=>handleOnChange(event, false, true),
                                        isFetchingStates: isFetchingBillingStates,
                                        isShipping: false,
                                        isBillingOrShipping: true
                                    })
                                ]
                            }) : null
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "your-orders",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-xl font-medium mb-4",
                                children: "Your Order"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(your_order, {
                                cart: cart
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(payment_modes, {
                                input: input,
                                handleOnChange: handleOnChange
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "woo-next-place-order-btn-wrap mt-5",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    disabled: isOrderProcessing,
                                    className: external_classnames_default()("bg-purple-600 text-white px-5 py-3 rounded-sm w-auto xl:w-full", {
                                        "opacity-50": isOrderProcessing
                                    }),
                                    type: "submit",
                                    children: "Place Order"
                                })
                            }),
                            isOrderProcessing && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Processing Order..."
                            }),
                            requestError && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "Error : ",
                                    requestError,
                                    " :( Please try again"
                                ]
                            })
                        ]
                    })
                ]
            })
        }) : null
    });
};
/* harmony default export */ const checkout_form = (CheckoutForm);

;// CONCATENATED MODULE: ./pages/checkout.js





function Checkout({ headerFooter , countries  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        headerFooter: headerFooter || {},
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                children: "Checkout"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(checkout_form, {
                countriesData: countries
            })
        ]
    });
};
async function getStaticProps() {
    const { data: headerFooterData  } = await external_axios_default().get(endpoints/* HEADER_FOOTER_ENDPOINT */.jp);
    return {
        props: {
            headerFooter: headerFooterData?.data ?? {}
        },
        /**
		 * Revalidate means that if a new request comes to server, then every 1 sec it will check
		 * if the data is changed, if it is changed then it will update the
		 * static file inside .next folder with the new data, so that any 'SUBSEQUENT' requests should have updated data.
		 */ revalidate: 1
    };
}


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 1320:
/***/ ((module) => {

module.exports = require("dompurify");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,63,675,162,366,584], () => (__webpack_exec__(7843)));
module.exports = __webpack_exports__;

})();