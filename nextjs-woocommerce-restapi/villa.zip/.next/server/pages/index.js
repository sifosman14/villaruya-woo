"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 9727:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/components/image/index.js + 1 modules
var components_image = __webpack_require__(1584);
// EXTERNAL MODULE: ./src/utils/miscellaneous.js
var miscellaneous = __webpack_require__(8301);
// EXTERNAL MODULE: ./src/components/cart/add-to-cart.js
var add_to_cart = __webpack_require__(3000);
// EXTERNAL MODULE: ./src/components/products/external-link.js
var external_link = __webpack_require__(4085);
;// CONCATENATED MODULE: ./src/components/products/product.js







const Product = ({ product  })=>{
    if ((0,external_lodash_.isEmpty)(product)) {
        return null;
    }
    const img = product?.images?.[0] ?? {};
    const productType = product?.type ?? "";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "mt-4 mb-8 px-3 w-full overflow-hidden sm:w-1/2 md:w-1/3 xl:w-1/4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: `/product/${product?.slug}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(components_image/* default */.Z, {
                            sourceUrl: img?.src ?? "",
                            altText: img?.alt ?? "",
                            title: product?.name ?? "",
                            width: "380",
                            height: "380"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                            className: "font-bold uppercase my-2 tracking-0.5px",
                            children: product?.name ?? ""
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mb-4",
                            dangerouslySetInnerHTML: {
                                __html: (0,miscellaneous/* sanitize */.N)(product?.price_html ?? "")
                            }
                        })
                    ]
                })
            }),
            "simple" === productType ? /*#__PURE__*/ jsx_runtime_.jsx(add_to_cart/* default */.Z, {
                product: product
            }) : null,
            "external" === productType ? /*#__PURE__*/ jsx_runtime_.jsx(external_link/* default */.Z, {
                url: product?.external_url ?? "",
                text: product?.button_text ?? ""
            }) : null
        ]
    });
};
/* harmony default export */ const products_product = (Product);

;// CONCATENATED MODULE: ./src/components/products/index.js



const Products = ({ products  })=>{
    if ((0,external_lodash_.isEmpty)(products) || !(0,external_lodash_.isArray)(products)) {
        return null;
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex flex-wrap -mx-3 overflow-hidden",
        children: products.length ? products.map((product)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx(products_product, {
                product: product
            }, product?.id);
        }) : null
    });
};
/* harmony default export */ const components_products = (Products);

// EXTERNAL MODULE: ./src/utils/constants/endpoints.js
var endpoints = __webpack_require__(7163);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: ./src/utils/products.js
var utils_products = __webpack_require__(4267);
// EXTERNAL MODULE: ./src/components/layout/index.js + 14 modules
var layout = __webpack_require__(6970);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/hero/index.js


function HeroSection() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative h-screen overflow-hidden",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: "https://backend.villaruya.co.za/wp-content/uploads/2023/03/Beach-Towel.webp",
                alt: "Hero background image",
                layout: "fill",
                objectFit: "cover"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute inset-0 bg-opacity-50 bg-black"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "absolute inset-0 flex items-center justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "text-white text-5xl font-medium mb-4",
                            children: "Welcome to Villaruya!"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-white text-xl mb-8",
                            children: "We offer the finest Turkish towels for your luxury lifestyle."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "bg-white text-black rounded px-8 py-4 font-bold hover:bg-gray-200",
                            children: "Shop Now"
                        })
                    ]
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./pages/index.js
/**
 * Internal Dependencies.
 */ 


/**
 * External Dependencies.
 */ 



function Home({ headerFooter , products  }) {
    const seo = {
        title: "Next JS WooCommerce REST API",
        description: "Next JS WooCommerce Theme",
        og_image: [],
        og_site_name: "React WooCommerce Theme",
        robots: {
            index: "index",
            follow: "follow"
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        headerFooter: headerFooter || {},
        seo: seo,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(HeroSection, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_products, {
                products: products
            })
        ]
    });
};
async function getStaticProps() {
    const { data: headerFooterData  } = await external_axios_default().get(endpoints/* HEADER_FOOTER_ENDPOINT */.jp);
    const { data: products  } = await (0,utils_products/* getProductsData */.d)();
    return {
        props: {
            headerFooter: headerFooterData?.data ?? {},
            products: products ?? {}
        },
        /**
		 * Revalidate means that if a new request comes to server, then every 1 sec it will check
		 * if the data is changed, if it is changed then it will update the
		 * static file inside .next folder with the new data, so that any 'SUBSEQUENT' requests should have updated data.
		 */ revalidate: 1
    };
}


/***/ }),

/***/ 1824:
/***/ ((module) => {

module.exports = require("@woocommerce/woocommerce-rest-api");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 1320:
/***/ ((module) => {

module.exports = require("dompurify");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,63,675,162,366,584,680], () => (__webpack_exec__(9727)));
module.exports = __webpack_exports__;

})();