"use strict";
(() => {
var exports = {};
exports.id = 190;
exports.ids = [190];
exports.modules = {

/***/ 8067:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Cart),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/layout/index.js + 14 modules
var layout = __webpack_require__(6970);
// EXTERNAL MODULE: ./src/utils/constants/endpoints.js
var endpoints = __webpack_require__(7163);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/context/index.js
var context = __webpack_require__(6086);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
// EXTERNAL MODULE: ./src/components/image/index.js + 1 modules
var components_image = __webpack_require__(1584);
// EXTERNAL MODULE: ./src/utils/cart/index.js + 2 modules
var utils_cart = __webpack_require__(9366);
;// CONCATENATED MODULE: ./src/components/cart/cart-item.js





const CartItem = ({ item , products , setCart  })=>{
    const { 0: productCount , 1: setProductCount  } = (0,external_react_.useState)(item.quantity);
    const { 0: updatingProduct , 1: setUpdatingProduct  } = (0,external_react_.useState)(false);
    const { 0: removingProduct , 1: setRemovingProduct  } = (0,external_react_.useState)(false);
    const productImg = item?.data?.images?.[0] ?? "";
    /**
	 * Do not allow state update on an unmounted component.
	 *
	 * isMounted is used so that we can set it's value to false
	 * when the component is unmounted.
	 * This is done so that setState ( e.g setRemovingProduct ) in asynchronous calls
	 * such as axios.post, do not get executed when component leaves the DOM
	 * due to product/item deletion.
	 * If we do not do this as unsubscription, we will get
	 * "React memory leak warning- Can't perform a React state update on an unmounted component"
	 *
	 * @see https://dev.to/jexperton/how-to-fix-the-react-memory-leak-warning-d4i
	 * @type {React.MutableRefObject<boolean>}
	 */ const isMounted = (0,external_react_.useRef)(false);
    (0,external_react_.useEffect)(()=>{
        isMounted.current = true;
        // When component is unmounted, set isMounted.current to false.
        return ()=>{
            isMounted.current = false;
        };
    }, []);
    /*
	 * Handle remove product click.
	 *
	 * @param {Object} event event
	 * @param {Integer} Product Id.
	 *
	 * @return {void}
	 */ const handleRemoveProductClick = (event, cartKey)=>{
        event.stopPropagation();
        // If the component is unmounted, or still previous item update request is in process, then return.
        if (!isMounted || updatingProduct) {
            return;
        }
        (0,utils_cart/* deleteCartItem */.GR)(cartKey, setCart, setRemovingProduct);
    };
    /*
	 * When user changes the qty from product input update the cart in localStorage
	 * Also update the cart in global context
	 *
	 * @param {Object} event event
	 *
	 * @return {void}
	 */ const handleQtyChange = (event, cartKey, type)=>{
        if (false) {}
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "cart-item-wrap grid grid-cols-3 gap-6 mb-5 border border-brand-bright-grey p-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-span-1 cart-left-col",
                children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(components_image/* default */.Z, {
                        width: "300",
                        height: "300",
                        altText: productImg?.alt ?? "",
                        sourceUrl: !(0,external_lodash_.isEmpty)(productImg?.src) ? productImg?.src : ""
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-span-2 cart-right-col",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-between flex-col h-full",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "cart-product-title-wrap relative",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "cart-product-title text-brand-orange",
                                    children: item?.data?.name
                                }),
                                item?.data?.description ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: item?.data?.description
                                }) : "",
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "cart-remove-item absolute right-0 top-0 px-4 py-2 flex items-center text-22px leading-22px bg-transparent border border-brand-bright-grey",
                                    onClick: (event)=>handleRemoveProductClick(event, item?.key),
                                    children: "\xd7"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
                            className: "cart-product-footer flex justify-between p-4 border-t border-brand-bright-grey",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "cart-total-price",
                                        children: [
                                            item?.currency,
                                            item?.line_subtotal
                                        ]
                                    })
                                }),
                                updatingProduct ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    className: "woo-next-cart-item-spinner",
                                    width: "24",
                                    src: "/cart-spinner.gif",
                                    alt: "spinner"
                                }) : null,
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    style: {
                                        display: "flex",
                                        alignItems: "center"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "decrement-btn text-24px",
                                            onClick: (event)=>handleQtyChange(event, item?.cartKey, "decrement"),
                                            children: "-"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            type: "number",
                                            min: "1",
                                            style: {
                                                textAlign: "center",
                                                width: "50px",
                                                paddingRight: "0"
                                            },
                                            "data-cart-key": item?.data?.cartKey,
                                            className: `woo-next-cart-qty-input ml-3 ${updatingProduct ? "disabled" : ""} `,
                                            value: productCount,
                                            onChange: (event)=>handleQtyChange(event, item?.cartKey, "")
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "increment-btn text-20px",
                                            onClick: (event)=>handleQtyChange(event, item?.cartKey, "increment"),
                                            children: "+"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const cart_item = (CartItem);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/cart/cart-items-container.js






const CartItemsContainer = ()=>{
    const { 0: cart , 1: setCart  } = (0,external_react_.useContext)(context/* AppContext */.I);
    const { cartItems , totalPrice , totalQty  } = cart || {};
    const { 0: isClearCartProcessing , 1: setClearCartProcessing  } = (0,external_react_.useState)(false);
    // Clear the entire cart.
    const handleClearCart = async (event)=>{
        event.stopPropagation();
        if (isClearCartProcessing) {
            return;
        }
        await (0,utils_cart/* clearCart */.LL)(setCart, setClearCartProcessing);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "content-wrap-cart",
        children: cart ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "woo-next-cart-table-row grid lg:grid-cols-3 gap-4",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "woo-next-cart-table lg:col-span-2 mb-md-0 mb-5",
                    children: cartItems.length && cartItems.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(cart_item, {
                            item: item,
                            products: cartItems,
                            setCart: setCart
                        }, item.product_id))
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "woo-next-cart-total-container lg:col-span-1 p-5 pt-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: "Cart Total"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex grid grid-cols-3 bg-gray-100 mb-4",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "col-span-2 p-2 mb-0",
                                    children: [
                                        "Total(",
                                        totalQty,
                                        ")"
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "col-span-1 p-2 mb-0",
                                    children: [
                                        cartItems?.[0]?.currency ?? "",
                                        totalPrice
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-between",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "clear-cart",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "text-gray-900 bg-white border border-gray-300 hover:bg-gray-100 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2 dark:bg-gray-600 dark:text-white dark:border-gray-600 dark:hover:bg-gray-700 dark:hover:border-gray-700 dark:focus:ring-gray-800",
                                        onClick: (event)=>handleClearCart(event),
                                        disabled: isClearCartProcessing,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "woo-next-cart",
                                            children: !isClearCartProcessing ? "Clear Cart" : "Clearing..."
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/checkout",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        className: "text-white duration-500 bg-brand-orange hover:bg-brand-royal-blue focus:ring-4 focus:text-white font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2 dark:focus:ring-yellow-900",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "woo-next-cart-checkout-txt",
                                                children: "Proceed to Checkout"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "fas fa-long-arrow-alt-right"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "mt-14",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    children: "No items in the cart"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                        className: "text-white duration-500 bg-brand-orange hover:bg-brand-royal-blue font-medium rounded-lg text-sm px-5 py-2.5 text-center mr-2 mb-2 dark:focus:ring-yellow-900",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "woo-next-cart-checkout-txt",
                                children: "Add New Products"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fas fa-long-arrow-alt-right"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const cart_items_container = (CartItemsContainer);

;// CONCATENATED MODULE: ./pages/cart.js





function Cart({ headerFooter  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        headerFooter: headerFooter || {},
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "uppercase tracking-0.5px",
                children: "Cart"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(cart_items_container, {})
        ]
    });
};
async function getStaticProps() {
    const { data: headerFooterData  } = await external_axios_default().get(endpoints/* HEADER_FOOTER_ENDPOINT */.jp);
    return {
        props: {
            headerFooter: headerFooterData?.data ?? {}
        },
        /**
		 * Revalidate means that if a new request comes to server, then every 1 sec it will check
		 * if the data is changed, if it is changed then it will update the
		 * static file inside .next folder with the new data, so that any 'SUBSEQUENT' requests should have updated data.
		 */ revalidate: 1
    };
}


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 1320:
/***/ ((module) => {

module.exports = require("dompurify");

/***/ }),

/***/ 6517:
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,63,675,162,366,584], () => (__webpack_exec__(8067)));
module.exports = __webpack_exports__;

})();