"use strict";
exports.id = 366;
exports.ids = [366];
exports.modules = {

/***/ 9366:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Xq": () => (/* binding */ addToCart),
  "LL": () => (/* binding */ clearCart),
  "GR": () => (/* binding */ deleteCartItem)
});

// UNUSED EXPORTS: updateCart, viewCart

// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
;// CONCATENATED MODULE: ./src/utils/cart/session.js

const storeSession = (session)=>{
    if ((0,external_lodash_.isEmpty)(session)) {
        return null;
    }
    localStorage.setItem("x-wc-session", session);
};
const getSession = ()=>{
    return localStorage.getItem("x-wc-session");
};

;// CONCATENATED MODULE: ./src/utils/cart/api.js


const api_getApiCartConfig = ()=>{
    const config = {
        headers: {
            "X-Headless-CMS": true
        }
    };
    const storedSession = getSession();
    if (!(0,external_lodash_.isEmpty)(storedSession)) {
        config.headers["x-wc-session"] = storedSession;
    }
    return config;
};

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: ./src/utils/constants/endpoints.js
var endpoints = __webpack_require__(7163);
;// CONCATENATED MODULE: ./src/utils/cart/index.js





/**
 * Add To Cart Request Handler.
 *
 * @param {int} productId Product Id.
 * @param {int} qty Product Quantity.
 * @param {Function} setCart Sets The New Cart Value
 * @param {Function} setIsAddedToCart Sets A Boolean Value If Product Is Added To Cart.
 * @param {Function} setLoading Sets A Boolean Value For Loading State.
 */ const addToCart = (productId, qty = 1, setCart, setIsAddedToCart, setLoading)=>{
    const storedSession = getSession();
    const addOrViewCartConfig = api_getApiCartConfig();
    setLoading(true);
    external_axios_default().post(endpoints/* CART_ENDPOINT */.Qw, {
        product_id: productId,
        quantity: qty
    }, addOrViewCartConfig).then((res)=>{
        if ((0,external_lodash_.isEmpty)(storedSession)) {
            storeSession(res?.headers?.["x-wc-session"]);
        }
        setIsAddedToCart(true);
        setLoading(false);
        viewCart(setCart);
    }).catch((err)=>{
        console.log("err", err);
    });
};
/**
 * View Cart Request Handler
 *
 * @param {Function} setCart Set Cart Function.
 * @param {Function} setProcessing Set Processing Function.
 */ const viewCart = (setCart, setProcessing = ()=>{})=>{
    const addOrViewCartConfig = api_getApiCartConfig();
    external_axios_default().get(endpoints/* CART_ENDPOINT */.Qw, addOrViewCartConfig).then((res)=>{
        const formattedCartData = getFormattedCartData(res?.data ?? []);
        setCart(formattedCartData);
        setProcessing(false);
    }).catch((err)=>{
        console.log("err", err);
        setProcessing(false);
    });
};
/**
 * Update Cart Request Handler
 */ const updateCart = (cartKey, qty = 1, setCart, setUpdatingProduct)=>{
    const addOrViewCartConfig = getApiCartConfig();
    setUpdatingProduct(true);
    axios.put(`${CART_ENDPOINT}${cartKey}`, {
        quantity: qty
    }, addOrViewCartConfig).then((res)=>{
        viewCart(setCart, setUpdatingProduct);
    }).catch((err)=>{
        console.log("err", err);
        setUpdatingProduct(false);
    });
};
/**
 * Delete a cart item Request handler.
 *
 * Deletes all products in the cart of a
 * specific product id ( by its cart key )
 * In a cart session, each product maintains
 * its data( qty etc ) with a specific cart key
 *
 * @param {String} cartKey Cart Key.
 * @param {Function} setCart SetCart Function.
 * @param {Function} setRemovingProduct Set Removing Product Function.
 */ const deleteCartItem = (cartKey, setCart, setRemovingProduct)=>{
    const addOrViewCartConfig = api_getApiCartConfig();
    setRemovingProduct(true);
    external_axios_default()["delete"](`${endpoints/* CART_ENDPOINT */.Qw}${cartKey}`, addOrViewCartConfig).then((res)=>{
        viewCart(setCart, setRemovingProduct);
    }).catch((err)=>{
        console.log("err", err);
        setRemovingProduct(false);
    });
};
/**
 * Clear Cart Request Handler
 *
 * @param {Function} setCart Set Cart
 * @param {Function} setClearCartProcessing Set Clear Cart Processing.
 */ const clearCart = async (setCart, setClearCartProcessing)=>{
    setClearCartProcessing(true);
    const addOrViewCartConfig = api_getApiCartConfig();
    try {
        const response = await external_axios_default()["delete"](endpoints/* CART_ENDPOINT */.Qw, addOrViewCartConfig);
        viewCart(setCart, setClearCartProcessing);
    } catch (err) {
        console.log("err", err);
        setClearCartProcessing(false);
    }
};
/**
 * Get Formatted Cart Data.
 *
 * @param cartData
 * @return {null|{cartTotal: {totalQty: number, totalPrice: number}, cartItems: ({length}|*|*[])}}
 */ const getFormattedCartData = (cartData)=>{
    if (!cartData.length) {
        return null;
    }
    const cartTotal = calculateCartQtyAndPrice(cartData || []);
    return {
        cartItems: cartData || [],
        ...cartTotal
    };
};
/**
 * Calculate Cart Qty And Price.
 *
 * @param cartItems
 * @return {{totalQty: number, totalPrice: number}}
 */ const calculateCartQtyAndPrice = (cartItems)=>{
    const qtyAndPrice = {
        totalQty: 0,
        totalPrice: 0
    };
    if (!(0,external_lodash_.isArray)(cartItems) || !cartItems?.length) {
        return qtyAndPrice;
    }
    cartItems.forEach((item, index)=>{
        qtyAndPrice.totalQty += item?.quantity ?? 0;
        qtyAndPrice.totalPrice += item?.line_total ?? 0;
    });
    return qtyAndPrice;
};


/***/ })

};
;