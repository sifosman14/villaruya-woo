"use strict";
exports.id = 584;
exports.ids = [584];
exports.modules = {

/***/ 1584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_image)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./src/utils/constants/images.js
const DEFAULT_IMG_URL = "https://via.placeholder.com/380x380";

;// CONCATENATED MODULE: ./src/components/image/index.js





/**
 * Image Component.
 * We don't need to add srcSet, as Next js will generate that.
 * @see https://nextjs.org/docs/api-reference/next/image#other-props
 * @see https://nextjs.org/docs/basic-features/image-optimization#device-sizes
 *
 * @param {Object} props Component props.
 *
 * @return {jsx}
 */ const Image = (props)=>{
    const { altText , title , width , height , sourceUrl , className , layout , objectFit , containerClassNames , showDefault , ...rest } = props;
    if (!sourceUrl && !showDefault) {
        return null;
    }
    /**
	 * If we use layout = fill then, width and height of the image cannot be used.
	 * and the image fills on the entire width and the height of its parent container.
	 * That's we need to wrap our image in a container and give it a height and width.
	 * Notice that in this case, the given height and width is being used for container and not img.
	 */ if ("fill" === layout) {
        const attributes = {
            alt: altText || title,
            src: sourceUrl || (showDefault ? DEFAULT_IMG_URL : ""),
            layout: "fill",
            className: external_classnames_default()("object-cover", className),
            ...rest
        };
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: external_classnames_default()("relative", containerClassNames),
            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                ...attributes
            })
        });
    } else {
        const attributes1 = {
            alt: altText || title,
            src: sourceUrl || (showDefault ? DEFAULT_IMG_URL : ""),
            width: width || "auto",
            height: height || "auto",
            className,
            ...rest
        };
        return /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            ...attributes1
        });
    }
};
Image.propTypes = {
    altText: (external_prop_types_default()).string,
    title: (external_prop_types_default()).string,
    sourceUrl: (external_prop_types_default()).string,
    layout: (external_prop_types_default()).string,
    showDefault: (external_prop_types_default()).bool,
    containerClassName: (external_prop_types_default()).string,
    className: (external_prop_types_default()).string
};
Image.defaultProps = {
    altText: "",
    title: "",
    sourceUrl: "",
    showDefault: true,
    containerClassNames: "",
    className: "product__image"
};
/* harmony default export */ const components_image = (Image);


/***/ })

};
;