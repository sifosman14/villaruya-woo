"use strict";
exports.id = 162;
exports.ids = [162];
exports.modules = {

/***/ 6086:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ AppContext),
/* harmony export */   "w": () => (/* binding */ AppProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const AppContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext([
    {},
    ()=>{}
]);
const AppProvider = (props)=>{
    const { 0: cart , 1: setCart  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    /**
	 * This will be called once on initial load ( component mount ).
	 *
	 * Sets the cart data from localStorage to `cart` in the context.
	 */ (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (false) {}
    }, []);
    /**
	 * 1.When setCart() is called that changes the value of 'cart',
	 * this will set the new data in the localStorage.
	 *
	 * 2.The 'cart' will anyways have the new data, as setCart()
	 * would have set that.
	 */ (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (false) {}
    }, [
        cart
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AppContext.Provider, {
        value: [
            cart,
            setCart
        ],
        children: props.children
    });
};


/***/ }),

/***/ 3447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function SvgArrowDown(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        height: "1em",
        viewBox: "0 0 24 24",
        width: "1em",
        className: "arrow-down_svg__fill-current arrow-down_svg__text-3xl",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M24 24H0V0h24v24z",
                fill: "none",
                opacity: 0.87
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M16.59 8.59L12 13.17 7.41 8.59 6 10l6 6 6-6-1.41-1.41z"
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgArrowDown);


/***/ }),

/***/ 9009:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function SvgBag(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        width: 18,
        height: "auto",
        stroke: "currentColor",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgBag);


/***/ }),

/***/ 3781:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function SvgLoading(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 64,
        height: 64,
        viewBox: "0 0 48 48",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M45.43 17.395h-34.5a46.41 46.41 0 00-2.446-.157c-1.511-.054-3.027-.015-4.539-.015-.574 0-1.125.047-1.648.187A2.573 2.573 0 000 19.965a2.576 2.576 0 002.57 2.574h42.86A2.576 2.576 0 0048 19.965a2.577 2.577 0 00-2.57-2.57zM2.57 22.023c-.613 0-1.16-.273-1.539-.703.418.375 1.004.578 1.59.703zm16.922-.261a.736.736 0 00.082.261h-1.097c.125-.968.128-1.96-.004-2.93.027-.316.062-.628.113-.94a.259.259 0 00-.086-.239h1.086c-.008 1.273-.254 2.586-.094 3.848zm.504-1.45c.02-.296.035-.59.055-.882.015.218.023.437.023.652-.004.586-.05 1.176.098 1.746-.356-.125-.192-1.305-.176-1.515zm2.95 1.711H21.84a.357.357 0 00.027-.054c.192-.64.207-1.356.188-2.067.004-.011.004-.027.008-.043.101-.64.117-1.293.12-1.945h.844c-.007 1.371-.086 2.738-.082 4.11zm22.484 0H24.324a.32.32 0 00-.062-.144c-.13-.16-.153-.473-.145-.8.074-.993.211-2.7.145-3.165H45.43a2.056 2.056 0 010 4.11zM3.086 29.781c-.016.063-.023.125-.016.192.082.539-.613.367-.914.359-.34-.012-1.05.09-1.176-.305-.156-.476-.074-1.078-.062-1.574a16.11 16.11 0 00-.168-2.644c-.043-.305-.504-.176-.46.125.194 1.324.026 2.668.187 3.992.078.64.132.824.726.84 1.242.035 2.574.199 2.227-1.043-.024-.09-.328.062-.344.058zm1.512-3.926c-.47.262-.422 1.207-.418 1.723.008.688-.075 1.379.043 2.059.16.93 1.308 1.238 1.976.633.977-.883.711-2.438.344-3.547-.266-.805-.695-1.567-1.945-.868zm1.156 4.149c-1.094.746-1.125-1.086-1.102-1.672.024-.535-.101-1.863.246-2.125 1.008-.762 1.254.824 1.383 1.34.196.808.239 1.937-.527 2.457zm3.844-4.484c-.102-.196-.368-.133-.438.02-.043.034-1.027 3.878-1.144 4.628-.047.289.43.32.476.035.07-.465.156-.933.254-1.398.5-.004 1 .023 1.5.011.16.516.336 1.024.57 1.512.13.266.555.07.426-.2-.707-1.476-.898-3.151-1.644-4.608zm-.754 2.835c.043-.19.09-.378.14-.566.133-.5.32-.988.45-1.488.277.668.472 1.367.675 2.066-.421 0-.843-.015-1.265-.012zm5.766-2.66c-.524-.492-1.465-.46-2.137-.386-.301.03-.235.394-.23.48.07 1.453.07 2.922.179 4.371.008.11.082.176.168.2a.25.25 0 00.215.07c1.66-.262 2.965-1.028 2.633-2.813-.133-.707-.274-1.402-.829-1.922zm-1.723 4.262c-.094-1.383-.102-2.789-.168-4.172a.113.113 0 00-.016-.055c.7-.09 1.438.024 1.867.622.29.398.375 1.125.43 1.59.16 1.347-.969 1.808-2.113 2.015zm4.105-4.633c-.203.692-.14 4.031-.125 5.008.004.309.48.3.477-.008-.012-.77-.14-4.031.11-4.879.089-.297-.372-.414-.462-.12zm5.118-.097c.007-.282-.47-.274-.477.007-.02.735.12 3.528 0 4.227-.098.578-.914-2.93-2.004-4.188-.29-.335-.52.07-.52.07 0 1.38.078 3.278.051 4.93-.004.282.473.274.477-.007.023-1.282.168-2.657.074-3.926.535 1.125 1.18 2.73 1.656 3.89.067.16.258.204.399.09.527-.422.316-4.07.343-5.093zm3.55 2.648c-.305 0-.297.422.008.422.867 0 .555 1.445.016 1.633-.457.164-1.067.058-1.493-.125-.515-.223-.472-1.176-.476-1.582-.004-.688.3-3.414 1.683-2.618.043.024.364.243.426.38.047.105.16.175.293.14.117-.027.211-.152.164-.262-.11-.242-.633-.656-.695-.648-2.254-1.235-2.484 3.2-2.191 4.219.296 1.035 1.886 1.25 2.812.73.855-.477.578-2.289-.547-2.289zm0 0",
            fill: "#3a3a3a"
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgLoading);


/***/ }),

/***/ 6970:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/components/context/index.js
var context = __webpack_require__(6086);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "lodash"
var external_lodash_ = __webpack_require__(6517);
// EXTERNAL MODULE: ./src/components/icons/ArrowDown.js
var ArrowDown = __webpack_require__(3447);
// EXTERNAL MODULE: ./src/components/icons/Bag.js
var Bag = __webpack_require__(9009);
;// CONCATENATED MODULE: ./src/components/icons/BurgerIcon.js


function SvgBurgerIcon(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: "burger-icon_svg__fill-current burger-icon_svg__h-3 burger-icon_svg__w-3",
        viewBox: "0 0 20 20",
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z"
        })
    });
}
/* harmony default export */ const BurgerIcon = (SvgBurgerIcon);

;// CONCATENATED MODULE: ./src/components/icons/Facebook.js


function SvgFacebook(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 24,
        height: 24,
        viewBox: "0 0 18 18",
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M2.637 18h5.87v-6.398H6.399v-2.11h2.11V6.855a2.64 2.64 0 012.637-2.636h2.636v2.11h-2.11c-.581 0-1.054.472-1.054 1.054v2.11h3.07l-.351 2.109h-2.719V18h4.746A2.64 2.64 0 0018 15.363V2.637A2.64 2.64 0 0015.363 0H2.637A2.64 2.64 0 000 2.637v12.726A2.64 2.64 0 002.637 18zM1.055 2.637c0-.871.71-1.582 1.582-1.582h12.726c.871 0 1.582.71 1.582 1.582v12.726c0 .871-.71 1.582-1.582 1.582h-3.691v-4.289h2.555l.703-4.219h-3.258V7.383h3.164V3.164h-3.691a3.696 3.696 0 00-3.692 3.691v1.582h-2.11v4.22h2.11v4.288H2.637c-.871 0-1.582-.71-1.582-1.582zm0 0",
            fill: "#fff"
        })
    });
}
/* harmony default export */ const Facebook = (SvgFacebook);

;// CONCATENATED MODULE: ./src/components/icons/Instagram.js


function SvgInstagram(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 24,
        height: 24,
        viewBox: "0 0 18 18",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            fill: "#fff",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M2.637 18h12.726A2.64 2.64 0 0018 15.363V2.637A2.64 2.64 0 0015.363 0H2.637A2.64 2.64 0 000 2.637v12.726A2.64 2.64 0 002.637 18zM1.055 2.637c0-.871.71-1.582 1.582-1.582h12.726c.871 0 1.582.71 1.582 1.582v12.726c0 .871-.71 1.582-1.582 1.582H2.637c-.871 0-1.582-.71-1.582-1.582zm0 0"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M9 13.746A4.751 4.751 0 0013.746 9 4.751 4.751 0 009 4.254 4.751 4.751 0 004.254 9 4.751 4.751 0 009 13.746zM9 5.31A3.696 3.696 0 0112.691 9 3.696 3.696 0 019 12.691 3.696 3.696 0 015.309 9 3.696 3.696 0 019 5.309zm0 0M14.273 5.309c.872 0 1.582-.711 1.582-1.582 0-.872-.71-1.582-1.582-1.582-.87 0-1.582.71-1.582 1.582 0 .87.711 1.582 1.582 1.582zm0-2.11a.53.53 0 01.528.528.53.53 0 01-.528.527.53.53 0 01-.527-.527.53.53 0 01.527-.528zm0 0"
                })
            ]
        })
    });
}
/* harmony default export */ const Instagram = (SvgInstagram);

// EXTERNAL MODULE: ./src/components/icons/Loading.js
var Loading = __webpack_require__(3781);
;// CONCATENATED MODULE: ./src/components/icons/SearchIcon.js


function SvgSearchIcon(props) {
    return /*#__PURE__*/ _jsx("svg", {
        viewBox: "0 0 24 24",
        ...props,
        children: /*#__PURE__*/ _jsx("path", {
            d: "M10 4a6 6 0 100 12 6 6 0 000-12zm-8 6a8 8 0 1114.32 4.906l5.387 5.387a1 1 0 01-1.414 1.414l-5.387-5.387A8 8 0 012 10z"
        })
    });
}
/* harmony default export */ const SearchIcon = ((/* unused pure expression or super */ null && (SvgSearchIcon)));

;// CONCATENATED MODULE: ./src/components/icons/TailwindIcon.js


function SvgTailwindIcon(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        className: "tailwind-icon_svg__fill-current tailwind-icon_svg__h-8 tailwind-icon_svg__w-8 tailwind-icon_svg__mr-2",
        width: 54,
        height: 54,
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M13.5 22.1c1.8-7.2 6.3-10.8 13.5-10.8 10.8 0 12.15 8.1 17.55 9.45 3.6.9 6.75-.45 9.45-4.05-1.8 7.2-6.3 10.8-13.5 10.8-10.8 0-12.15-8.1-17.55-9.45-3.6-.9-6.75.45-9.45 4.05zM0 38.3c1.8-7.2 6.3-10.8 13.5-10.8 10.8 0 12.15 8.1 17.55 9.45 3.6.9 6.75-.45 9.45-4.05-1.8 7.2-6.3 10.8-13.5 10.8-10.8 0-12.15-8.1-17.55-9.45-3.6-.9-6.75.45-9.45 4.05z"
        })
    });
}
/* harmony default export */ const TailwindIcon = (SvgTailwindIcon);

;// CONCATENATED MODULE: ./src/components/icons/Twitter.js


function SvgTwitter(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 24,
        height: 24,
        viewBox: "0 0 18 18",
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M18 1.969c-1.133.05-1.11.047-1.234.058L17.434.11s-2.09.774-2.622.91C13.418-.233 11.348-.288 9.864.622 8.653 1.367 8 2.648 8.22 4.145 5.859 3.816 3.87 2.695 2.3.813L1.805.215l-.371.68a4.142 4.142 0 00-.442 2.773c.078.379.207.742.387 1.082l-.426-.164-.05.71c-.051.724.19 1.567.644 2.259.129.195.293.406.5.617l-.219-.031.27.816a3.957 3.957 0 002.039 2.36c-.953.402-1.719.66-2.98 1.074L0 12.773l1.066.582c.407.223 1.844.965 3.262 1.188 3.156.496 6.711.09 9.102-2.063 2.015-1.816 2.675-4.394 2.539-7.082-.02-.406.09-.793.312-1.093.45-.594 1.715-2.332 1.719-2.336zm-2.559 1.707a2.712 2.712 0 00-.523 1.777c.137 2.707-.602 4.809-2.191 6.246-1.864 1.672-4.864 2.332-8.235 1.801-.61-.094-1.242-.309-1.762-.523 1.06-.364 1.875-.688 3.196-1.313l1.84-.871-2.036-.129c-.972-.062-1.785-.535-2.28-1.305.265-.011.519-.054.773-.129l1.941-.539-1.957-.48a2.915 2.915 0 01-2.164-2.086c.195.05.422.09.793.125l1.809.18L3.21 5.313c-1.035-.81-1.45-2.02-1.145-3.184 3.227 3.348 7.012 3.094 7.395 3.183-.086-.816-.086-.816-.11-.894-.488-1.727.583-2.602 1.067-2.898 1.008-.622 2.605-.715 3.715.308a.95.95 0 00.867.23c.27-.066.496-.14.71-.218l-.452 1.3h.582c-.11.15-.242.325-.399.536zm0 0",
            fill: "#fff"
        })
    });
}
/* harmony default export */ const Twitter = (SvgTwitter);

;// CONCATENATED MODULE: ./src/components/icons/User.js


function SvgUser(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        width: 18,
        height: "auto",
        stroke: "currentColor",
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zm-4 7a7 7 0 00-7 7h14a7 7 0 00-7-7z"
        })
    });
}
/* harmony default export */ const User = (SvgUser);

;// CONCATENATED MODULE: ./src/components/icons/Wishlist.js


function SvgWishlist(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        width: 18,
        height: "auto",
        stroke: "currentColor",
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"
        })
    });
}
/* harmony default export */ const Wishlist = (SvgWishlist);

;// CONCATENATED MODULE: ./src/components/icons/Youtube.js


function SvgYoutube(props) {
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 24,
        height: 24,
        viewBox: "0 0 18 18",
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            fill: "#fff",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M2.637 13.71h12.726A2.64 2.64 0 0018 11.075V2.637A2.64 2.64 0 0015.363 0H2.637A2.64 2.64 0 000 2.637v8.437a2.64 2.64 0 002.637 2.637zM1.055 2.638c0-.871.71-1.582 1.582-1.582h12.726c.871 0 1.582.71 1.582 1.582v8.437c0 .871-.71 1.582-1.582 1.582H2.637c-.871 0-1.582-.71-1.582-1.582zm0 0"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M6.363 3.324v7.168l6.348-3.644zm1.055 1.79l3.144 1.75-3.144 1.804zm0 0"
                })
            ]
        })
    });
}
/* harmony default export */ const Youtube = (SvgYoutube);

;// CONCATENATED MODULE: ./src/components/icons/index.js













;// CONCATENATED MODULE: ./src/components/layout/header/index.js






const Header = ({ header  })=>{
    const { 0: cart , 1: setCart  } = (0,external_react_.useContext)(context/* AppContext */.I);
    const { headerMenuItems , siteDescription , siteLogoUrl , siteTitle  } = header || {};
    const { 0: isMenuVisible , 1: setMenuVisibility  } = (0,external_react_.useState)(false);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "header",
            children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                className: "bg-white py-5",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center justify-between flex-wrap container mx-auto",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex items-center flex-shrink-0 text-black mr-20",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        children: siteLogoUrl ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            className: "mr-2",
                                            src: siteLogoUrl,
                                            alt: `${siteTitle} logo`,
                                            width: "156",
                                            height: "156"
                                        }) : /*#__PURE__*/ jsx_runtime_.jsx(TailwindIcon, {})
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "font-semibold text-xl tracking-tight",
                                                children: siteTitle
                                            })
                                        }),
                                        siteDescription ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "mb-0",
                                            children: siteDescription
                                        }) : null
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "block lg:hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                onClick: ()=>setMenuVisibility(!isMenuVisible),
                                className: "flex items-center px-3 py-2 border rounded text-black border-black hover:text-black hover:border-black",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(BurgerIcon, {
                                    className: "fill-current h-3 w-3"
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `${isMenuVisible ? "max-h-full" : "h-0"} overflow-hidden w-full lg:h-full block flex-grow lg:flex lg:items-center lg:w-auto`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-sm font-medium uppercase lg:flex-grow",
                                    children: !(0,external_lodash_.isEmpty)(headerMenuItems) && headerMenuItems.length ? headerMenuItems.map((menuItem)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: menuItem?.url ?? "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "block mt-4 lg:inline-block lg:mt-0 hover:text-brand-royal-blue duration-500 mr-10",
                                                dangerouslySetInnerHTML: {
                                                    __html: menuItem.title
                                                }
                                            })
                                        }, menuItem?.ID)) : null
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "text-sm font-medium",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "#responsive-header",
                                            className: "flex mt-4 lg:inline-block lg:mt-0 text-black hover:text-black mr-10",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "flex flex-row items-center lg:flex-col",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(User, {
                                                        className: "mr-1 lg:mr-0"
                                                    }),
                                                    "Profile"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "#responsive-header",
                                            className: "flex mt-4 lg:inline-block lg:mt-0 text-black hover:text-black mr-10",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "flex flex-row items-center lg:flex-col",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Wishlist, {
                                                        className: "mr-1 lg:mr-0"
                                                    }),
                                                    "Wishlist"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/cart",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "flex mt-4 lg:inline-block lg:mt-0 text-black hover:text-black mr-10",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                    className: "flex flex-row items-center lg:flex-col",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Bag/* default */.Z, {
                                                            className: "mr-1 lg:mr-0"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                            className: "ml-1",
                                                            children: [
                                                                "Bag",
                                                                cart?.totalQty ? `(${cart?.totalQty})` : null
                                                            ]
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const layout_header = (Header);

// EXTERNAL MODULE: ./src/utils/miscellaneous.js
var miscellaneous = __webpack_require__(8301);
;// CONCATENATED MODULE: ./src/utils/icons-map.js


/**
 * Icons Component map.
 *
 * @param {string} name Icon Name.
 * @returns {*}
 */ const getIconComponentByName = (name)=>{
    const ComponentsMap = {
        facebook: Facebook,
        twitter: Twitter,
        instagram: Instagram,
        youtube: Youtube
    };
    if (name in ComponentsMap) {
        const IconComponent = ComponentsMap[name];
        return /*#__PURE__*/ jsx_runtime_.jsx(IconComponent, {});
    } else {
        return null;
    }
};

;// CONCATENATED MODULE: ./src/components/layout/footer/index.js
/**
 * Internal Dependencies.
 */ 


/**
 * External Dependencies.
 */ 


const Footer = ({ footer  })=>{
    const { copyrightText , footerMenuItems , sidebarOne , sidebarTwo , socialLinks  } = footer || {};
    const { 0: isMounted , 1: setMount  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        setMount(true);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: "footer bg-black p-6",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "container mx-auto",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-wrap -mx-1 overflow-hidden text-white",
                    children: [
                        isMounted ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "my-1 px-1 w-full overflow-hidden sm:w-full lg:w-1/2 xl:w-1/3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        dangerouslySetInnerHTML: {
                                            __html: (0,miscellaneous/* sanitize */.N)(sidebarOne)
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "my-2 pl-12 px-1 w-full overflow-hidden sm:w-full lg:w-1/2 xl:w-1/3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        dangerouslySetInnerHTML: {
                                            __html: (0,miscellaneous/* sanitize */.N)(sidebarTwo)
                                        }
                                    })
                                })
                            ]
                        }) : null,
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-right my-1 px-1 w-full overflow-hidden sm:w-full lg:w-1/2 xl:w-1/3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                    children: "Useful Links"
                                }),
                                !(0,external_lodash_.isEmpty)(footerMenuItems) && (0,external_lodash_.isArray)(footerMenuItems) ? /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    children: footerMenuItems.map((menuItem)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                href: menuItem?.url ?? "/",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    children: menuItem?.title
                                                })
                                            })
                                        }, menuItem?.ID))
                                }) : null
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mb-8 mt-8 w-full flex flex-wrap",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full md:w-1/2 lg:w-1/4 text-white",
                            children: copyrightText ? copyrightText : "\xa9 OWD 2022"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full lg:w-3/4 flex justify-end",
                            children: !(0,external_lodash_.isEmpty)(socialLinks) && (0,external_lodash_.isArray)(socialLinks) ? /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                className: "flex item-center mb-0",
                                children: socialLinks.map((socialLink)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "no-dots-list mb-0 flex items-center",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            href: socialLink?.iconUrl || "/",
                                            target: "_blank",
                                            title: socialLink?.iconName,
                                            className: "ml-2 inline-block",
                                            children: [
                                                getIconComponentByName(socialLink?.iconName),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "sr-only",
                                                    children: socialLink?.iconName
                                                })
                                            ]
                                        })
                                    }, socialLink?.iconName))
                            }) : null
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const layout_footer = (Footer);

// EXTERNAL MODULE: external "next-seo"
var external_next_seo_ = __webpack_require__(6641);
// EXTERNAL MODULE: external "prop-types"
var external_prop_types_ = __webpack_require__(580);
var external_prop_types_default = /*#__PURE__*/__webpack_require__.n(external_prop_types_);
;// CONCATENATED MODULE: ./src/components/seo/index.js



/**
 * Custom SEO component
 *
 * Used to seo meta tags for each page
 *
 * @param {Object} seo Seo.
 * @param {string} uri Page URI.
 * @see https://www.npmjs.com/package/next-seo
 *
 * @returns {JSX.Element}
 *
 */ const Seo = ({ seo , uri  })=>{
    if (!Object.keys(seo).length) {
        return null;
    }
    const { title , description , og_title , og_description , og_image , og_site_name , robots ,  } = seo || {};
    const currentLocation =  false ? 0 : null;
    const opengraphUrl = ( true ? "http://localhost:3000" : 0) + uri;
    return /*#__PURE__*/ jsx_runtime_.jsx(external_next_seo_.NextSeo, {
        title: title || og_title,
        description: description || og_description,
        canonical: opengraphUrl,
        noindex: "noindex" === robots?.index,
        nofollow: "nofollow" === robots?.follow,
        robotsProps: {
            maxSnippet: parseInt(robots?.["max-snippet"]?.replace("max-snippet:", "") ?? ""),
            maxImagePreview: robots?.["max-image-preview"]?.replace("max-image-preview:", "") ?? "",
            maxVideoPreview: parseInt(robots?.["max-video-preview"]?.replace("max-video-preview:", "") ?? "")
        },
        openGraph: {
            type: "website",
            locale: "en_US",
            url: opengraphUrl,
            title: og_title,
            description: og_description,
            images: [
                {
                    url: og_image.length ? og_image[0]?.url ?? "" : "",
                    width: 1280,
                    height: 720
                }, 
            ],
            site_name: og_site_name
        },
        twitter: {
            handle: "@Codeytek",
            site: "@Codeytek",
            cardType: "summary_large_image"
        }
    });
};
Seo.propTypes = {
    seo: (external_prop_types_default()).object
};
Seo.defaultProps = {
    seo: {
        title: "",
        description: "",
        og_title: "",
        og_description: "",
        og_image: [],
        og_site_name: "",
        robots: {
            follow: "",
            index: ""
        },
        article_modified_time: ""
    }
};
/* harmony default export */ const components_seo = (Seo);

;// CONCATENATED MODULE: ./src/components/layout/index.js
/**
 * External Dependencies
 */ 

/**
 * Internal Dependencies.
 */ 




const Layout = ({ children , headerFooter , seo , uri  })=>{
    const { header , footer  } = headerFooter || {};
    const yoastSchema = seo?.schema ? (0,miscellaneous/* replaceBackendWithFrontendUrl */.h)(JSON.stringify(seo.schema)) : null;
    return /*#__PURE__*/ jsx_runtime_.jsx(context/* AppProvider */.w, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(components_seo, {
                    seo: seo || {},
                    uri: uri || ""
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("link", {
                            rel: "shortcut icon",
                            href: header?.favicon ?? "/favicon.ico"
                        }),
                        yoastSchema ? /*#__PURE__*/ jsx_runtime_.jsx("script", {
                            type: "application/ld+json",
                            className: "yoast-schema-graph",
                            dangerouslySetInnerHTML: {
                                __html: (0,miscellaneous/* sanitize */.N)(yoastSchema)
                            }
                        }, "yoastSchema") : /*#__PURE__*/ jsx_runtime_.jsx("title", {
                            children: header?.siteTitle ?? "Nexts WooCommerce"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(layout_header, {
                    header: header
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("main", {
                    className: "container mx-auto py-4 min-h-50vh",
                    children: children
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(layout_footer, {
                    footer: footer
                })
            ]
        })
    });
};
/* harmony default export */ const layout = (Layout);


/***/ }),

/***/ 7163:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Qw": () => (/* binding */ CART_ENDPOINT),
/* harmony export */   "jp": () => (/* binding */ HEADER_FOOTER_ENDPOINT),
/* harmony export */   "yd": () => (/* binding */ WOOCOMMERCE_STATES_ENDPOINT)
/* harmony export */ });
/* unused harmony exports GET_PRODUCTS_ENDPOINT, WOOCOMMERCE_COUNTRIES_ENDPOINT */
const HEADER_FOOTER_ENDPOINT = `${"https://backend.villaruya.co.za/"}/wp-json/rae/v1/header-footer?header_location_id=hcms-menu-header&footer_location_id=hcms-menu-footer`;
const GET_PRODUCTS_ENDPOINT = (/* unused pure expression or super */ null && (`${"http://localhost:3000"}/api/get-products`));
/**
 * Cart
 * @type {string}
 */ const CART_ENDPOINT = `${"https://backend.villaruya.co.za/"}/wp-json/rae/v1/cart/items/`;
// Countries and States
const WOOCOMMERCE_COUNTRIES_ENDPOINT = (/* unused pure expression or super */ null && (`${"https://backend.villaruya.co.za/"}/wp-json/wc/v3/data/countries/`));
const WOOCOMMERCE_STATES_ENDPOINT = `${"https://backend.villaruya.co.za/"}/wp-json/wc/v3/data/states/`;


/***/ }),

/***/ 8301:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ sanitize),
/* harmony export */   "h": () => (/* binding */ replaceBackendWithFrontendUrl)
/* harmony export */ });
/* harmony import */ var dompurify__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1320);
/* harmony import */ var dompurify__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(dompurify__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Sanitize markup or text when used inside dangerouslysetInnerHTML
 *
 * @param {string} content Plain or html string.
 *
 * @return {string} Sanitized string
 */ const sanitize = (content)=>{
    return  false ? 0 : content;
};
/**
 * Replace backend url with front-end url.
 *
 * @param {String} data Data.
 *
 * @return formattedData Formatted data.
 */ const replaceBackendWithFrontendUrl = (data)=>{
    if (!data || "string" !== typeof data) {
        return "";
    }
    // First replace all the backend-url with front-end url
    let formattedData = data.replaceAll("https://backend.villaruya.co.za/", "http://localhost:3000");
    // Replace only the upload urls for images back to back to back-end url, since images are hosted in the backend.
    return formattedData.replaceAll(`${"http://localhost:3000"}/wp-content/uploads`, `${"https://backend.villaruya.co.za/"}/wp-content/uploads`);
};


/***/ })

};
;